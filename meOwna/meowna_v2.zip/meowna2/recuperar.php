<?php
/**
 * LAB — Recuperação de Senha (OTP SEM RATE LIMIT)
 * ⚠️ ATENÇÃO: Código intencionalmente vulnerável para fins educacionais.
 */

include 'configuracao_db.php';
$conn = db_connect();

$otpSent  = false;
$otpValid = false;
$otpError = false;

// ETAPA 1 — SOLICITAÇÃO E ENVIO DO EMAIL
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = $_POST['email'];

    // Gera OTP entre 111 e 999
    $otp = random_int(111, 999);

    // ⚠️ VULNERÁVEL A SQL INJECTION
    // Sempre sobrescreve a MESMA linha (id = 1) conforme a lógica do lab
    $sql = "INSERT INTO password_recovery (id, email, otp)
            VALUES (1, '$email', '$otp')
            ON DUPLICATE KEY UPDATE
                email = '$email',
                otp   = '$otp'";

    $conn->query($sql);
    $otpSent = true;
}

// ETAPA 2 — VALIDAÇÃO DO CÓDIGO OTP
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['otp'])) {
    $otp = $_POST['otp'];

    // ⚠️ VULNERÁVEL A SQL INJECTION
    $sql = "SELECT * FROM password_recovery WHERE otp = '$otp'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $otpValid = true;
    } else {
        $otpError = true;
    }

    // Mantém o estado para exibir o formulário de confirmação
    $otpSent = true;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Venue - Recuperação de Senha</title>
    
    <meta name="description" content="Laboratório de Segurança">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="css/fontAwesome.css">
    <link rel="stylesheet" href="css/hero-slider.css">
    <link rel="stylesheet" href="css/owl-carousel.css">
    <link rel="stylesheet" href="css/datepicker.css">
    <link rel="stylesheet" href="css/templatemo-style.css">
    <link rel="icon" type="image/x-icon" href="img/icone.png">
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900" rel="stylesheet">

    <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    <script src="js/users-login.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.6.0/angular.js"></script>
</head>

<body>
    <div class="wrap">
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <button id="primary-nav-button" type="button">Menu</button>
                        <a href="index.php">
                            <div class="logo">
                                <img src="img/logo.png" alt="Venue Logo">
                            </div>
                        </a>
                        <nav id="primary-nav" class="dropdown cf">
                            <ul class="dropdown menu">
                                <li class="active"><a href="index.php">Início</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
    </div>
      
    <section class="banner" id="top">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="banner-caption">
                        <div class="line-dec"></div>
                        <h2>Sou vulnerável, me Owna</h2>
                        <span>Abra seu sistema Kali Linux, Parrot, Black Arch ou BackBox e divirta-se.</span>
                        <div class="blue-button">
                            <a href="manual.pdf">Como hackear este site</a>
                        </div>
                    </div>

                    <div class="submit-form">
                        <form id="form-submit" method="POST" action="">
                            <div class="row">
                                <div class="col-md-3 first-item">
                                    <fieldset>
                                        <input name="user" type="text" class="form-control" id="name" placeholder="Nome de usuário" disabled>
                                    </fieldset>
                                </div>
                                <div class="col-md-3 second-item">
                                    <fieldset>
                                        <input name="email" type="email" class="form-control" id="location" placeholder="E-mail" required>
                                    </fieldset>
                                </div>
                                <div class="col-md-3 third-item">
                                    <fieldset>
                                        <input name="senha" type="password" class="form-control" placeholder="Senha" disabled>
                                    </fieldset>
                                </div>
                                <input name="admin" type="hidden" id="adm">
                                <div class="col-md-3">
                                    <fieldset>
                                        <button type="submit" class="btn">Recuperar</button>
                                    </fieldset>
                                </div>
                            </div>
                        </form>

                        <?php if ($otpSent): ?>
                            <div class="row" style="margin-top: 30px;">
                                <div class="col-md-12">
                                    <div class="alert alert-info">
                                        Código OTP enviado para o e-mail informado.
                                    </div>

                                    <form method="POST" action="">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <fieldset>
                                                    <input name="otp" type="text" class="form-control" placeholder="Digite o OTP (XXX)" required>
                                                </fieldset>
                                            </div>
                                            <div class="col-md-3">
                                                <fieldset>
                                                    <button type="submit" class="btn">Confirmar OTP</button>
                                                </fieldset>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if ($otpValid): ?>
                            <div class="alert alert-success" style="margin-top:20px;">
                                ✅ OTP válido! O usuário pode redefinir a senha agora.
                            </div>
                        <?php endif; ?>

                        <?php if ($otpError): ?>
                            <div class="alert alert-danger" style="margin-top:20px;">
                                ❌ OTP inválido! Tente novamente
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="about-veno">
                        <div class="logo">
                            <img src="img/footer_logo.png" alt="Venue Logo" onclick="document.location='index.php'">
                        </div>
                        <p>Pratique seus conhecimentos de hacking de forma ética e controlada.</p>
                        <ul class="social-icons">
                            <li>
                                <a href="https://www.facebook.com/formminghackers/"><i class="fa fa-facebook"></i></a>
                                <a href="https://www.youtube.com/c/FORMMINGHACKERS"><i class="fa fa-youtube"></i></a>
                                <a href="https://www.instagram.com/formminghackers/"><i class="fa fa-instagram"></i></a>
                                <a href="https://formminghackers.com"><i class="fa fa-dribbble"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="useful-links">
                        <div class="footer-heading">
                            <h4>Links Interessantes</h4>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <ul>
                                    <li><a href="https://formminghackers.com">Formming Hackers</a></li>
                                    <li><a href="login.php">Login</a></li>
                                    <li><a href="manual.pdf">Tutorial</a></li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul>
                                    <li><a href="https://github.com/digininja/DVWA">DVWA</a></li>
                                    <li><a href="https://github.com/s4n7h0/xvwa">XVWA</a></li>
                                    <li><a href="https://www.vulnhub.com/">VULNHUB</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="contact-info">
                        <div class="footer-heading">
                            <h4>Contato</h4>
                        </div>
                        <ul>
                            <li><span>Telefone:</span> <a href="#">123-123-123</a></li>
                            <li><span>Email:</span> <a href="#">empresa@empresa.com</a></li>
                            <li><span>Endereço:</span> <a href="#">empresa.com</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <div class="sub-footer">
        <p>Copyright &copy; 2018 Company Name - Design: <a rel="nofollow" href="http://www.templatemo.com">Template Mo</a></p>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')</script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/datepicker.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
