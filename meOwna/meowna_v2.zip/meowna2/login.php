<?php
/**
 * LAB — Login Vulnerável (Timing Attack & LFI)
 *  ATENÇÃO: Código intencionalmente vulnerável para fins educacionais.
 */

// 1. Definição de Cookies (Deve vir antes de qualquer HTML)
setcookie("PHPSESSID", 'off');

// 2. Lógica do Laboratório
$senha_correta = "maria123456";
$login_status = null;

/**
 * Função intencionalmente vulnerável a timing attack.
 * O atraso de 50ms por caractere correto permite deduzir a senha.
 */
function insecure_compare($input, $expected) {
    for ($i = 0; $i < strlen($expected); $i++) {
        // Se o caractere está errado ou ausente
        if (!isset($input[$i]) || $input[$i] !== $expected[$i]) {
            usleep(50000); // 50ms
            return false;
        }
        // Caractere correto gera atraso acumulativo
        usleep(50000); 
    }
    return strlen($input) === strlen($expected);
}

// 3. Processamento do POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $senha = $_POST['senha'] ?? "";

    if (insecure_compare($senha, $senha_correta)) {
        $login_status = "success";
    } else {
        $login_status = "error";
    }
    // Removido o 'exit' para permitir que o restante da página carregue com o feedback
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Venue - Login de Usuário</title>
    
    <meta name="description" content="Laboratório de Hacking">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="css/fontAwesome.css">
    <link rel="stylesheet" href="css/hero-slider.css">
    <link rel="stylesheet" href="css/owl-carousel.css">
    <link rel="stylesheet" href="css/datepicker.css">
    <link rel="stylesheet" href="css/templatemo-style.css">
    <link rel="icon" type="image/x-icon" href="img/icone.png">
    
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    <script src="js/users-login.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.6.0/angular.js"></script>
</head>

<body>
    <div class="wrap">
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <button id="primary-nav-button" type="button">Menu</button>
                        <a href="index.php">
                            <div class="logo">
                                <img src="img/logo.png" alt="Venue Logo">
                            </div>
                        </a>
                        <nav id="primary-nav" class="dropdown cf">
                            <ul class="dropdown menu">
                                <li class="active"><a href="index.php">Início</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
    </div>
      
    <section class="banner" id="top">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="banner-caption">
                        <div class="line-dec"></div>
                        <h2>Sou vulnerável, me Owna</h2>
                        <span>Explore vulnerabilidades de tempo e inclusão de arquivos.</span>
                        <div class="blue-button">
                            <a href="manual.pdf">Como hackear este site</a>
                        </div>
                    </div>

                    <div class="submit-form">
                        <form id="form-submit" action="usuario.php?b=bio.txt" method="POST">
                            <div class="row">
                                <div class="col-md-3 first-item">
                                    <fieldset>
                                        <input name="user" type="text" class="form-control" placeholder="Nome de usuário" disabled>
                                    </fieldset>
                                </div>
                                <div class="col-md-3 second-item">
                                    <fieldset>
                                        <input name="email" type="email" class="form-control" placeholder="E-mail" required>
                                    </fieldset>
                                </div>
                                <div class="col-md-3 third-item">
                                    <fieldset>
                                        <input name="senha" type="password" class="form-control" placeholder="Senha" required>
                                    </fieldset>
                                </div>
                                <input name="admin" type="hidden" id="adm">
                                <div class="col-md-3">
                                    <fieldset>
                                        <button type="submit" class="btn">LOGIN</button>
                                    </fieldset>
                                </div>
                                <div class="col-md-12 recover-link" style="margin-top: 15px;">
                                    <a href="recuperar.php" style="color: #1E90FF; text-decoration: underline;">Esqueci minha senha</a>
                                </div>
                            </div>
                        </form>

                        <?php if ($login_status === "success"): ?>
                            <div class="alert alert-success" style="margin-top: 20px;">
                                <strong>Login OK!</strong> Bem-vindo ao sistema.
                            </div>
                        <?php elseif ($login_status === "error"): ?>
                            <div class="alert alert-danger" style="margin-top: 20px;">
                                <strong>Login FAIL!</strong> Senha incorreta.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="about-veno">
                        <div class="logo">
                            <img src="img/footer_logo.png" alt="Logo" onclick="document.location='index.php'">
                        </div>
                        <p>Plataforma de treinamento para entusiastas de cibersegurança.</p>
                        <ul class="social-icons">
                            <li>
                                <a href="https://www.facebook.com/formminghackers/"><i class="fa fa-facebook"></i></a>
                                <a href="https://www.youtube.com/c/FORMMINGHACKERS"><i class="fa fa-youtube"></i></a>
                                <a href="https://www.instagram.com/formminghackers/"><i class="fa fa-instagram"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="useful-links">
                        <div class="footer-heading">
                            <h4>Links Úteis</h4>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <ul>
                                    <li><a href="login.php">Login</a></li>
                                    <li><a href="manual.pdf">Tutorial</a></li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul>
                                    <li><a href="https://www.vulnhub.com/">VulnHub</a></li>
                                    <li><a href="https://github.com/digininja/DVWA">DVWA</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="contact-info">
                        <div class="footer-heading">
                            <h4>Contato</h4>
                        </div>
                        <ul>
                            <li><span>Telefone:</span> 123-123-123</li>
                            <li><span>Email:</span> empresa@empresa.com</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <div class="sub-footer">
        <p>Copyright &copy; 2018 Company Name - Design: <a rel="nofollow" href="http://www.templatemo.com">Template Mo</a></p>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')</script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
