<?php

http_response_code(200);

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Contexto Técnico sobre Status Codes HTTP</title>
  <style>
    body {
      font-family: Arial, Helvetica, sans-serif;
      line-height: 1.6;
      color: #222;
      max-width: 900px;
      margin: 40px auto;
      padding: 0 20px;
    }
    h1, h2 {
      color: #0f172a;
    }
    h1 {
      font-size: 28px;
      margin-bottom: 20px;
    }
    h2 {
      font-size: 22px;
      margin-top: 30px;
      margin-bottom: 10px;
    }
    p {
      margin-bottom: 15px;
      text-align: justify;
    }
    ul {
      margin-left: 20px;
      margin-bottom: 15px;
    }
    li {
      margin-bottom: 6px;
    }
    .highlight {
      background: #f1f5f9;
      border-left: 4px solid #2563eb;
      padding: 15px;
      margin: 20px 0;
    }
    #logo img{
    	cursor: pointer;
    }
  </style>
</head>
<body>
<div class="logo" id="logo">
  <img src="../../img/logo.png" alt="Venue Logo">
</div>

<script>
  document.querySelector('.logo').addEventListener('click', () => {
    location.assign('../../index.php');
  });
</script>

  <h1>Contexto Técnico sobre Status Codes HTTP</h1>

  <p>
    O ponto central é entender que <strong>respostas HTTP são definidas pelo back-end</strong> 
    e fazem parte da lógica da aplicação. Um mesmo caminho base pode retornar 
    <strong>status codes diferentes</strong> dependendo da rota completa, da forma de acesso 
    ou do contexto da requisição.
  </p>

  <p>
    Por exemplo, uma rota base como <code>/api</code> pode retornar <strong>404</strong>, 
    enquanto uma rota mais específica à frente dela, como <code>/api/admin/</code>, 
    pode retornar <strong>200</strong>, <strong>301</strong>, <strong>403</strong> ou 
    <strong>500</strong>, indicando que existe processamento ou lógica implementada 
    naquele endpoint.
  </p>

  <p>
    Ferramentas de <strong>fuzzing</strong> e <strong>descoberta de rotas</strong> são usadas 
    justamente para identificar esses comportamentos e mapear a superfície real da aplicação.
  </p>

  <div class="highlight">
    <p>
      Pequenas variações na requisição — como a presença ou ausência da barra final (<code>/</code>), 
      redirecionamentos automáticos, headers diferentes ou parâmetros adicionais — 
      podem alterar completamente a resposta do servidor.
    </p>
  </div>

  <h2>Aprendizado Principal para Pentest</h2>

  <p>
    Durante um teste de segurança, <strong>não descarte um endpoint apenas com base 
    em um status code HTTP isolado</strong>. Dependendo do contexto, um endpoint que 
    inicialmente retorna <strong>404</strong> pode se transformar em <strong>200</strong> 
    ao explorar variações como:
  </p>

  <ul>
    <li>Rotas mais profundas</li>
    <li>Redirecionamentos (3xx)</li>
    <li>Alterações na estrutura da URL</li>
    <li>Headers HTTP</li>
    <li>Parâmetros adicionais</li>
  </ul>

  <p>
    Também é fundamental lembrar que os status codes são organizados por 
    <strong>famílias</strong>, cada uma com um significado específico:
  </p>

  <ul>
    <li><strong>100–199</strong>: Informativo</li>
    <li><strong>200–299</strong>: Sucesso</li>
    <li><strong>300–399</strong>: Redirecionamento</li>
    <li><strong>400–499</strong>: Erro do cliente</li>
    <li><strong>500–599</strong>: Erro do servidor</li>
  </ul>

  <h2>Conclusão</h2>

  <p>
    Hacking e pentest são atividades <strong>totalmente baseadas em contexto e lógica</strong>. 
    O comportamento de uma aplicação não pode ser avaliado apenas por uma resposta inicial. 
    Entender como a aplicação foi programada, testar variações e interpretar corretamente 
    os status codes faz parte de uma análise profissional de segurança.
  </p>

</body>
</html>
