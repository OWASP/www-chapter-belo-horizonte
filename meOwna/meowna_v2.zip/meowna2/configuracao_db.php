<?php
$DB_HOST = '127.0.0.1';
$DB_USER = 'root';
$DB_PASS = 'toor';
$DB_NAME = 'meowna';

function db_connect() {
    $conn = new mysqli($GLOBALS['DB_HOST'], $GLOBALS['DB_USER'], $GLOBALS['DB_PASS'], $GLOBALS['DB_NAME']);
    if ($conn->connect_errno) die('Erro: ' . $conn->connect_error);
    if (!$conn->select_db($GLOBALS['DB_NAME'])) die('Erro DB');
    return $conn;
}
?>