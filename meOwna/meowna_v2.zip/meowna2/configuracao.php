<?php
/**
 * Configurações de Segurança e Sessão
 */
header("Content-Security-Policy: script-src 'self';");

if (!isset($_COOKIE['PHPSESSID']) || $_COOKIE['PHPSESSID'] !== "on") {
    header('Location: login.php');
    exit;
}

/**
 * ===============================================
 * INSECURE DESERIALIZATION — Cookie vulnerável
 * ===============================================
 */
class PerfilUsuario {
    public $nome;

    public function __construct($nome = "Maria") {
        $this->nome = $nome;
    }
}

$cookie_nome = "perfil_data";

if (!isset($_COOKIE[$cookie_nome])) {
    $obj = new PerfilUsuario("Maria");
    $encoded = base64_encode(serialize($obj));

    // Cookie sem proteção — parte da vulnerabilidade
    setcookie($cookie_nome, $encoded, time() + 3600, "/", "", false, false);
    $perfil = $obj;
} else {
    // Cookie existe: Decodifica e desserializa (VULNERÁVEL)
    $decoded = base64_decode($_COOKIE[$cookie_nome]);
    $perfil = @unserialize($decoded);

    if (!is_object($perfil)) {
        $perfil = new PerfilUsuario("Maria (erro)");
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Venue - Responsive Web Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="css/fontAwesome.css">
    <link rel="stylesheet" href="css/hero-slider.css">
    <link rel="stylesheet" href="css/owl-carousel.css">
    <link rel="stylesheet" href="css/datepicker.css">
    <link rel="stylesheet" href="css/templatemo-style.css">
    <link rel="icon" type="image/x-icon" href="img/icone.png">
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    
    <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.6.0/angular.js"></script>

    <style>
        body {
            padding-left: 25px;
            padding-right: 25px;
        }

        .botaoAzul, input[name="usuarioLinkedin"] {
            font-family: Arial;
            background-color: #0000FF;
            border: none;
            color: white;
            padding: 16px 32px;
            text-align: center;
            font-size: 16px;
            margin: 4px 2px;
            opacity: 0.6;
            transition: 0.3s;
            display: inline-block;
            text-decoration: none;
            cursor: pointer;
        }

        .botaoAzul:hover, input[name="usuarioLinkedin"]:hover {
            opacity: 1;
        }

        button[name="excluirConta"] {
            font-family: Arial;
            background-color: #8B0000;
            border: none;
            color: white;
            padding: 9px 18px;
            text-align: center;
            font-size: 16px;
            margin: 4px 2px;
            opacity: 0.6;
            transition: 0.3s;
            display: inline-block;
            text-decoration: none;
            cursor: pointer;
            border-radius: 10px;
        }

        button[name="excluirConta"]:hover {
            opacity: 1;
        }

        button[name="visitarLinkedin"] {
            background-color: white;
            color: black;
            border: 2px solid #0000FF;
            border-radius: 10px;
        }

        #user {
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="wrap">
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <button id="primary-nav-button" type="button">Menu</button>
                        <a href="index.html">
                            <div class="logo">
                                <img src="img/logo.png" onclick="document.location='index.php'" alt="Venue Logo">
                            </div>
                        </a>
                        <nav id="primary-nav" class="dropdown cf">
                            <ul class="dropdown menu">
                                <li class='active'><a href="index.php">Início</a></li>
                                <li>
                                    <a href="#">Para estudar</a>
                                    <ul class="sub-menu">
                                        <li><a href="https://formminghackers.com">Formming Hackers</a></li>
                                        <li><a href="https://owasp.org/">OWASP</a></li>
                                        <li><a href="https://cwe.mitre.org/">CWE</a></li>
                                        <li><a href="https://defcon.org/">DEFCON</a></li>
                                    </ul>
                                </li>
                                <li><a class="scrollTo" data-scrollTo="blog" href="usuario.php?back=config.php&b=bio.txt">Usuário</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
    </div>

    <hr>

    <main class="container">
        <div id="user">
            <h1 style="color:blue; font-size: 525%;">Configurações do usuário</h1>
        </div>

        <table>
            <tr>
                <td style="width: 20%;">
                    <img src="img/girl-6024567_960_720.jpg" width="100%" style="border-radius: 50%;">
                </td>
                <td style="padding-left: 20px;">
                    <h3><span style="color:blue;">Usuário:</span> <?php echo htmlspecialchars($perfil->nome); ?></h3>
                    <h3><span style="color:blue;">E-mail:</span> maria@maria.com</h3>
                </td>
            </tr>
        </table>

        <form method="POST" action="" style="margin-top: 30px;">
            <h3>
                <span style="color:blue;">Confirme sua chave de API: </span>
                <input type="text" name="apiKey" placeholder="Ex: Y2hhdmUxMjM0NTY3ODkK">
            </h3>
            <input type="submit" class="botaoAzul" value="Confirmar" name="chaveAPI">
        </form>

        <?php
        if (isset($_POST['apiKey'])) {
            echo "<p style='margin-top:10px;'><span style='color:blue;'>Sua chave API decodificada: </span>" . base64_decode($_POST['apiKey']) . "</p>";
        }
        ?>

        <form method="POST" action="dados.php" style="margin-top: 20px;">
            <button type="submit" class="botaoAzul" value="users/user-5397.json" name="dados">Meus dados</button>
        </form>
        
        <div style="text-align: left; margin-top: 50px;">
            <hr>
            <form action="" method="POST">
                <button type="submit" value="true" name="excluirConta">Excluir minha conta</button>
            </form>
            <?php
            // Simulação de CSRF para exclusão de conta
            if (isset($_POST['excluirConta'])) {
                echo "<h3 style='color:red;'>Você excluiu sua conta!!</h3>";
            }
            ?>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="about-veno">
                        <div class="logo">
                            <img src="img/footer_logo.png" onclick="document.location='index.php'" alt="Venue Logo">
                        </div>
                        <p>Este site foi feito para você praticar seus conhecimentos de hacking, fique a vontade para Ownar</p>
                        <ul class="social-icons">
                            <li><a href="https://www.facebook.com/formminghackers/"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://www.youtube.com/c/FORMMINGHACKERS"><i class="fa fa-youtube"></i></a></li>
                            <li><a href="https://www.instagram.com/formminghackers/"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://formminghackers.com"><i class="fa fa-dribbble"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="useful-links">
                        <div class="footer-heading">
                            <h4>Links interessantes</h4>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <ul>
                                    <li><a href="https://formminghackers.com"><i class="fa fa-stop"></i>Formming Hackers</a></li>
                                    <li><a href="usuario.php?back=config.php&b=bio.txt"><i class="fa fa-stop"></i>Usuário</a></li>
                                    <li><a href="manual.pdf"><i class="fa fa-stop"></i>Como Hackear?</a></li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul>
                                    <li><a href="https://github.com/digininja/DVWA"><i class="fa fa-stop"></i>DVWA</a></li>
                                    <li><a href="https://github.com/s4n7h0/xvwa"><i class="fa fa-stop"></i>XVWA</a></li>
                                    <li><a href="https://www.vulnhub.com/"><i class="fa fa-stop"></i>VULNHUB</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="contact-info">
                        <div class="footer-heading">
                            <h4>Contato</h4>
                        </div>
                        <ul>
                            <li><span>Telefone:</span> 123-123-123</li>
                            <li><span>Email:</span> empresa@empresa.com</li>
                            <li><span>Endereço:</span> empresa.com</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <div class="sub-footer">
        <p>Copyright &copy; 2018 Company Name - Design: <a rel="nofollow" href="http://www.templatemo.com">Template Mo</a></p>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')</script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/datepicker.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
