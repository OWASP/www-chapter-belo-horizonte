<?php

http_response_code(404);

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Vulnerabilidade — Django DEBUG Ativado</title>
  <style>
    body {
      font-family: Arial, Helvetica, sans-serif;
      line-height: 1.6;
      color: #222;
      max-width: 900px;
      margin: 40px auto;
      padding: 0 20px;
    }
    h1, h2, h3 {
      color: #0f172a;
    }
    h1 {
      font-size: 28px;
      margin-bottom: 20px;
    }
    h2 {
      font-size: 22px;
      margin-top: 30px;
      margin-bottom: 10px;
    }
    h3 {
      font-size: 18px;
      margin-top: 20px;
      margin-bottom: 8px;
    }
    p {
      margin-bottom: 15px;
      text-align: justify;
    }
    ol {
      margin-left: 20px;
      margin-bottom: 15px;
    }
    li {
      margin-bottom: 8px;
    }
    .highlight {
      background: #f1f5f9;
      border-left: 4px solid #dc2626;
      padding: 15px;
      margin: 20px 0;
    }
    .info {
      background: #ecfeff;
      border-left: 4px solid #0284c7;
      padding: 15px;
      margin: 20px 0;
    }
    .fix {
      background: #f0fdf4;
      border-left: 4px solid #16a34a;
      padding: 15px;
      margin: 20px 0;
    }
    a {
      color: #2563eb;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
    .refs a {
      display: block;
      margin-bottom: 6px;
    }
    code {
      background: #e5e7eb;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 90%;
    }
    #logo img{
    	cursor: pointer;
    }
  </style>
</head>
<body>
<div class="logo" id="logo">
  <img src="../img/logo.png" alt="Venue Logo">
</div>

<script>
  document.querySelector('.logo').addEventListener('click', () => {
    location.assign('../index.php');
  });
</script>
  <h1>Vulnerabilidade Encontrada</h1>

  <div class="highlight">
    <p><strong>Vulnerabilidade:</strong> Modo <code>DEBUG</code> do Django ativado</p>
  </div>

  <p>
    O servidor web de destino está divulgando <strong>informações sensíveis do sistema</strong>
    por meio das respostas HTTP. Esse comportamento ocorre quando o modo de depuração do
    framework Django está habilitado em ambiente acessível externamente.
  </p>

  <p>
    O modo <code>DEBUG</code> foi projetado para auxiliar desenvolvedores durante o processo
    de desenvolvimento, fornecendo mensagens detalhadas de erro e contexto da aplicação.
    Quando exposto em produção, esse recurso também pode ser explorado por invasores.
  </p>

  <h2>Impacto</h2>

  <div class="info">
    <h3>Um invasor pode obter informações como:</h3>
    <ol>
      <li>Versão exata do Django e do Python em uso.</li>
      <li>Tipo de banco de dados utilizado, nome do banco e possíveis credenciais.</li>
      <li>Detalhes completos da configuração do projeto Django.</li>
      <li>Caminhos internos de arquivos e estrutura do sistema.</li>
      <li>Código-fonte exibido por exceções, variáveis locais e seus valores.</li>
    </ol>
  </div>

  <p>
    Essas informações reduzem significativamente o esforço de um atacante, facilitando a
    enumeração do ambiente, o entendimento da arquitetura da aplicação e o desenvolvimento
    de ataques mais direcionados.
  </p>

  <h2>Correção</h2>

  <div class="fix">
    <p>
      Para mitigar essa vulnerabilidade, ajuste o arquivo de configurações do Django e
      defina a opção <code>DEBUG</code> como <strong>False</strong> em ambientes de produção:
    </p>

    <p><code>DEBUG = False</code></p>

    <p>
      Além disso, certifique-se de que as configurações de erro, logging e tratamento de
      exceções estejam adequadamente ajustadas para não expor informações sensíveis.
    </p>
  </div>

  <h2>Referências</h2>

  <div class="refs">
    <a href="https://www.invicti.com/web-vulnerability-scanner/vulnerabilities/django-debug-mode-enabled/" target="_blank">
      Referência 1 — Django Debug Mode Enabled (Invicti)
    </a>
    <a href="https://medium.com/@syedabuthahir/django-debug-mode-to-rce-in-microsoft-acquisition-189d27d08971" target="_blank">
      Referência 2 — From Django Debug Mode to RCE
    </a>
  </div>

</body>
</html>


