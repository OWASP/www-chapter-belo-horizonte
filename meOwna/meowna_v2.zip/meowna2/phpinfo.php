<?php
/**
 * Exemplo didático de vulnerabilidade:
 * Information Disclosure via phpinfo()
 */
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Vulnerabilidade — Information Disclosure (phpinfo)</title>
  <style>
    body {
      font-family: Arial, Helvetica, sans-serif;
      line-height: 1.6;
      color: #222;
      max-width: 1000px;
      margin: 40px auto;
      padding: 0 20px;
    }
    h1, h2 {
      color: #0f172a;
    }
    h1 {
      font-size: 28px;
      margin-bottom: 20px;
      text-align: center;
    }
    h2 {
      font-size: 22px;
      margin-top: 30px;
      margin-bottom: 10px;
    }
    p {
      margin-bottom: 15px;
      text-align: justify;
    }
    .alert {
      background: #fff1f2;
      border-left: 5px solid #dc2626;
      padding: 20px;
      margin: 25px 0;
    }
    .info {
      background: #f1f5f9;
      border-left: 5px solid #2563eb;
      padding: 20px;
      margin: 25px 0;
    }
    .warning {
      background: #fff7ed;
      border-left: 5px solid #ea580c;
      padding: 20px;
      margin: 25px 0;
    }
    a {
      color: #2563eb;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
    code {
      background: #e5e7eb;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 90%;
    }
    .refs a {
      display: block;
      margin-bottom: 6px;
    }
    hr {
      margin: 40px 0;
      border: none;
      border-top: 1px solid #e5e7eb;
    }
    #logo img {
    	cursor: pointer;
    }
  </style>
</head>
<body>
<div class="logo" id="logo">
  <img src="img/logo.png" alt="Venue Logo">
</div>

<script>
  document.querySelector('.logo').addEventListener('click', () => {
    location.assign('index.php');
  });
</script><br><br>
  <h1>Vulnerabilidade Encontrada</h1>

  <div class="alert">
    <p>
      <strong>Tipo:</strong> Information Disclosure<br>
      <strong>Causa:</strong> Exposição da função <code>phpinfo()</code>
    </p>
  </div>

  <p>
    Este endpoint expõe informações sensíveis do ambiente PHP em execução por meio
    da função <code>phpinfo()</code>. Essa função foi projetada para fins de depuração
    e diagnóstico, porém <strong>não deve estar acessível em ambientes de produção</strong>.
  </p>

  <h2>Impacto</h2>

  <div class="warning">
    <p>
      A exposição do <code>phpinfo()</code> pode permitir que um atacante obtenha:
    </p>
    <ul>
      <li>Versão exata do PHP e módulos instalados</li>
      <li>Configurações de compilação e extensões habilitadas</li>
      <li>Caminhos internos do sistema de arquivos</li>
      <li>Variáveis de ambiente</li>
      <li>Informações sobre o servidor web e sistema operacional</li>
    </ul>
  </div>

  <p>
    Essas informações reduzem significativamente o esforço de enumeração do ambiente
    e podem ser utilizadas para direcionar ataques mais eficazes contra a aplicação.
  </p>

  <h2>Recomendação</h2>

  <div class="info">
    <p>
      Remova completamente o uso da função <code>phpinfo()</code> em ambientes de produção
      ou restrinja rigorosamente o acesso ao arquivo por meio de autenticação, controle
      de IP ou outros mecanismos de segurança.
    </p>
  </div>

  <h2>Referências</h2>

  <div class="refs">
    <a href="https://www.acunetix.com/vulnerabilities/web/phpinfo-output-detected/" target="_blank">
      Acunetix — PHPInfo Output Detected
    </a>
    <a href="https://www.invicti.com/web-vulnerability-scanner/vulnerabilities/information-disclosure-phpinfo/" target="_blank">
      Invicti — Information Disclosure via phpinfo
    </a>
  </div>

  <hr>

  <?php
  // Exposição proposital para fins educacionais
  phpinfo();
  ?>

</body>
</html>

