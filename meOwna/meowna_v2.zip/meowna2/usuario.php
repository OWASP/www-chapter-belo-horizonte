<?php
/**
 * Controle de Sessão
 */
if (!isset($_COOKIE['PHPSESSID']) || $_COOKIE['PHPSESSID'] !== "on") {
    header('Location: login.php');
    exit;
}

include 'configuracao_db.php';

/**
 * Endpoint API - Retorno de dados do usuário (Vulnerável a SQL Injection)
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user'])) {
    header("Content-Type: application/json; charset=UTF-8");
    $conn = db_connect();

    if ($conn->connect_errno) {
        echo json_encode(["erro" => "Falha de conexão com o banco"]);
        exit;
    }

    // INTENCIONALMENTE VULNERÁVEL: SQL Injection
    $user = $_POST['user'];
    $sql  = "SELECT usuario, email FROM usuarios WHERE usuario = '$user'";

    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $lista = [];
        while ($row = $result->fetch_assoc()) {
            $lista[] = [
                "usuario" => $row["usuario"],
                "email"   => $row["email"]
            ];
        }
        echo json_encode($lista);
        exit;
    }

    echo json_encode([[
        "usuario" => "Não encontrado",
        "email"   => "Não encontrado"
    ]]);
    exit;
}

/**
 * Lógica para carregamento da página (Likes)
 */
$conn = db_connect();
$totalLikes = 0;

if (!$conn->connect_errno) {
    $res = $conn->query("SELECT likes FROM posts WHERE id = 1");
    if ($res && $row = $res->fetch_assoc()) {
        $totalLikes = (int)$row['likes'];
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Venue - Perfil do Usuário</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="css/fontAwesome.css">
    <link rel="stylesheet" href="css/hero-slider.css">
    <link rel="stylesheet" href="css/owl-carousel.css">
    <link rel="stylesheet" href="css/datepicker.css">
    <link rel="stylesheet" href="css/templatemo-style.css">
    <link rel="icon" type="image/x-icon" href="img/icone.png">
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    
    <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.6.0/angular.js"></script>

    <style>
        body {
            padding-left: 25px;
            padding-right: 25px;
        }

        input[id="link"] {
            border: 2px solid blue;
            border-radius: 4px;
            padding: 8px 8px;
        }

        input[id="link"]:focus {
            outline: none;
        }

        .post-card {
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0,0,0,.1);
            padding: 15px;
            max-width: 520px;
            margin: 20px auto;
            font-family: Arial, sans-serif;
        }

        .post-header {
            display: flex;
            align-items: center;
        }

        .post-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 10px;
        }

        .post-user {
            font-weight: bold;
            color: #050505;
        }

        .post-date {
            font-size: 12px;
            color: #65676b;
        }

        .post-image {
            width: 100%;
            border-radius: 6px;
            margin-top: 12px;
        }

        .post-actions {
            display: flex;
            justify-content: space-around;
            border-top: 1px solid #ddd;
            margin-top: 12px;
            padding-top: 10px;
        }

        .post-actions span {
            cursor: pointer;
            font-weight: bold;
            color: #65676b;
        }

        .post-actions span.like {
            color: #1877f2;
        }

        .post-likes {
            margin-top: 8px;
            font-size: 14px;
            color: #65676b;
        }
    </style>
</head>

<body>
    <div class="wrap">
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <button id="primary-nav-button" type="button">Menu</button>
                        <a href="index.html">
                            <div class="logo">
                                <img src="img/logo.png" onclick="document.location='index.php'" alt="Venue Logo">
                            </div>
                        </a>
                        <nav id="primary-nav" class="dropdown cf">
                            <ul class="dropdown menu">
                                <li class="active"><a href="index.php">Início</a></li>
                                <li>
                                    <a class="scrollTo" data-scrollTo="blog" href="<?php echo isset($_GET['back']) ? htmlspecialchars($_GET['back']) : 'configuracao.php'; ?>">
                                        Configurações
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </header>
    </div>

    <hr>

    <main class="container">
        <div class="text-center">
            <h1 style="color:blue; font-size: 525%;">Perfil do usuário</h1>
        </div>

        <table style="width: 100%; margin-bottom: 30px;">
            <tr>
                <td style="width: 20%;">
                    <img src="img/girl-6024567_960_720.jpg" width="100%" style="border-radius: 50%;">
                </td>
                <td style="padding-left: 20px;">
                    <h3><span style="color:blue;">Usuário:</span> <span id="spanUser">Carregando...</span></h3>
                    <h3><span style="color:blue;">E-mail:</span> <span id="spanEmail">Carregando...</span></h3>
                </td>
            </tr>
        </table>

        <section>
            <h3>
                <span style="color:blue;">Biografia:</span>
                <?php
                if (isset($_GET['b'])) {
                    $biografia = urldecode(str_replace('/', '', $_GET['b']));
                    include($biografia);
                } else {
                    echo "<p style='color:red;'>Erro ao tentar carregar a biografia. :c</p>";
                }
                ?>
            </h3>
        </section>

        <div class="row" style="margin-top:40px;">
            <div class="col-md-7">
                <div style="margin-bottom: 20px;">
                    <input id="link" type="url" placeholder="URL - meu site">
                    <button style="background-color: white; border: 1px solid blue; border-radius: 5px;" id="botao" onclick="mostrarBotao()">
                        CADASTRAR
                    </button>
                    <p id="site"></p>
                </div>

                <button id="btnExportar" style="font-family:Arial; background-color:blue; color: white; border: none; border-radius: 4px; padding: 10px;">
                    Exportar dados da Maria
                </button>

                <div id="xmlOutput" style="margin-top: 20px; background-color: #1e1e1e; padding: 15px; border-radius: 8px; color: white; white-space: pre; font-family: monospace; display: none;"></div>

                <hr>

                <h3 style="color:blue;">Meus Livros</h3>
                <form action="" method="POST">
                    <select style="background-color: white; font-size: 23px; color: black; border: none; border-bottom: 2px solid blue;" name="livro">
                        <option value="https://github.com/OWASP/wstg/releases/download/v4.2/wstg-v4.2.pdf">WSTG - Web Security Testing Guide</option>
                        <option value="https://devguide.owasp.org/">OWASP Development Guide</option>
                        <option value="https://genai.owasp.org/resource/owasp-genai-security-project-solutions-reference-guide-q2_q325/">OWASP GenAI Security Project</option>
                    </select>
                    <input type="submit" value="Ler este livro" style="background-color: white; color: blue; border: none; border-radius: 4px; cursor: pointer;">
                </form>

                <?php
                if (isset($_POST['livro'])) {
                    echo "<div style='margin-top:10px;'><a href='" . $_POST['livro'] . "' style='background-color: #4169E1; font-size: 23px; color:white; padding:5px;'>Clique aqui</a></div>";
                }
                ?>

                <form enctype="multipart/form-data" action="" method="POST" style="margin-top: 30px;">
                    <h3 style="color:blue;">Faça upload de um livro:</h3>
                    <input style="background-color:white; color: blue; border: none; border-radius: 4px;" type="file" name="uploaded_file"><br/>
                    <input style="font-family:Arial; background-color:blue; color: white; border: none; border-radius: 4px; margin-top: 10px; padding: 5px 15px;" type="submit" value="Upload">
                </form>

                <?php
                if (!empty($_FILES['uploaded_file'])) {
                    $allowedTypes = ['image/png', 'application/pdf', 'image/jpg'];
                    $fileType = $_FILES['uploaded_file']['type'];
                    $fileName = basename($_FILES['uploaded_file']['name']);
                    $fileTmp  = $_FILES['uploaded_file']['tmp_name'];

                    if (!in_array($fileType, $allowedTypes)) {
                        echo "<p style='color:red;'>Tipo de arquivo não permitido!</p>";
                    } else {
                        $uploadPath = "uploads/" . $fileName;
                        if (move_uploaded_file($fileTmp, $uploadPath)) {
                            echo "<p style='color:green;'>Upload de {$fileName} concluído com sucesso!! <a href='/uploads/{$fileName}'>clique aqui</a></p>";
                        } else {
                            echo "<p style='color:red;'>Erro durante o upload, tente novamente!</p>";
                        }
                    }
                }
                ?>
            </div>

            <div class="col-md-5">
                <div class="post-card">
                    <div class="post-header">
                        <img src="img/girl-6024567_960_720.jpg" class="post-avatar">
                        <div>
                            <div class="post-user">Maria Silva</div>
                            <div class="post-date"><?php echo date("d/m/Y H:i"); ?></div>
                        </div>
                    </div>

                    <img src="img/gatinho.jpg" class="post-image">

                    <div class="post-actions">
                        <span class="like" id="likeBtn">👍 Curtir</span>
                        <span>💬 Comentar</span>
                        <span>↗ Compartilhar</span>
                    </div>

                    <div class="post-likes" id="likeBox">
                        ❤️ <span id="likeCount"><?php echo $totalLikes; ?></span> likes
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="about-veno">
                        <div class="logo">
                            <img src="img/footer_logo.png" onclick="document.location='index.php'" alt="Venue Logo">
                        </div>
                        <p>Este site foi feito para você praticar seus conhecimentos de hacking, fique a vontade para Ownar</p>
                        <ul class="social-icons">
                            <li><a href="https://www.facebook.com/formminghackers/"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://www.youtube.com/c/FORMMINGHACKERS"><i class="fa fa-youtube"></i></a></li>
                            <li><a href="https://www.instagram.com/formminghackers/"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://formminghackers.com"><i class="fa fa-dribbble"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="useful-links">
                        <div class="footer-heading">
                            <h4>Links interessantes</h4>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <ul>
                                    <li><a href="https://formminghackers.com"><i class="fa fa-stop"></i>Formming Hackers</a></li>
                                    <li><a href="configuracao.php"><i class="fa fa-stop"></i>Configurações</a></li>
                                    <li><a href="manual.pdf"><i class="fa fa-stop"></i>Como Hackear?</a></li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul>
                                    <li><a href="https://github.com/digininja/DVWA"><i class="fa fa-stop"></i>DVWA</a></li>
                                    <li><a href="https://github.com/s4n7h0/xvwa"><i class="fa fa-stop"></i>XVWA</a></li>
                                    <li><a href="https://www.vulnhub.com/"><i class="fa fa-stop"></i>VULNHUB</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="contact-info">
                        <div class="footer-heading">
                            <h4>Contato</h4>
                        </div>
                        <ul>
                            <li><span>Telefone:</span> 123-123-123</li>
                            <li><span>Email:</span> empresa@empresa.com</li>
                            <li><span>Endereço:</span> empresa.com</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <div class="sub-footer">
        <p>Copyright &copy; 2018 Company Name - Design: <a rel="nofollow" href="http://www.templatemo.com">Template Mo</a></p>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')</script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/datepicker.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

    <script>
        // Carregamento de dados via Fetch (Vulnerável a SQLi no corpo da requisição)
        setTimeout(() => {
            fetch("usuario.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "user=maria"
            })
            .then(resp => resp.json())
            .then(data => {
                const primeiro = data[0];
                document.getElementById("spanUser").textContent = primeiro.usuario;
                document.getElementById("spanEmail").textContent = primeiro.email;
            })
            .catch(err => {
                document.getElementById("spanUser").textContent = "Erro";
                document.getElementById("spanEmail").textContent = "Erro";
            });
        }, 2000);

        // Função vulnerável a Tabnabbing (window.open sem noopener)
        function mostrarBotao() {
            var urlCapturada = document.querySelector('#link').value;
            document.querySelector('#site').innerHTML =
                "<button style='background-color: white; border: 1px solid blue; color: black; border-radius: 5px; margin-top:10px;' onclick='window.open(`" + urlCapturada + "`)'>Meu site</button>";
            document.querySelector('#link').style.display = "none";
            document.querySelector('#botao').style.display = "none";
        }

        // Simulação de Exportação XML
        document.getElementById("btnExportar").addEventListener("click", function () {
            const xmlData = `<user><nome>maria</nome><email>maria@maria.com</email></user>`;
            const formData = new FormData();
            formData.append("xml_data", xmlData);

            fetch("export.php", {
                method: "POST",
                body: formData
            })
            .then(r => r.text())
            .then(xml => {
                const escaped = xml.replace(/</g, "&lt;").replace(/>/g, "&gt;");
                const formatted = escaped.replace(/(&lt;\/?[a-zA-Z0-9_]+&gt;)/g, '<span style="color:#ff6b6b;">$1</span>');
                const box = document.getElementById("xmlOutput");
                box.innerHTML = formatted;
                box.style.display = "none";
            })
            .catch(err => alert("Erro ao exportar: " + err));
        });

        // Evento de Like
        document.getElementById("likeBtn").addEventListener("click", () => {
            fetch("like.php", { method: "POST" })
            .then(r => r.json())
            .then(d => {
                if (typeof d.likes !== "undefined") {
                    document.getElementById("likeCount").innerText = d.likes;
                }
            });
        });
    </script>
</body>
</html>