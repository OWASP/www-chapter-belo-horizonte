<?php
/**
 * INSTALADOR DO LABORATÓRIO - meOwna
 * Finalidade: Configurar ambiente em distros de Pentest (Kali, Parrot, BlackArch, Debian, Arch).
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// ---------------------------------------------------------
// FUNÇÕES DE APOIO
// ---------------------------------------------------------

/**
 * Detecta o SO e instala as dependências (MariaDB, MySQLi e XML)
 */
function instalar_dependencias_sistema() {
    $log = "";
    $os_info = file_exists('/etc/os-release') ? file_get_contents('/etc/os-release') : '';
    
    $is_arch_based = (strpos($os_info, 'ID=arch') !== false || strpos($os_info, 'ID=blackarch') !== false);
    $is_debian_based = (strpos($os_info, 'ID=debian') !== false || strpos($os_info, 'ID=kali') !== false || strpos($os_info, 'ID=parrot') !== false || strpos($os_info, 'ID_LIKE=debian') !== false);

    if (!$is_arch_based && !$is_debian_based) {
        return "Sistema não identificado. Tente instalar manualmente.";
    }

    $log .= "🔍 Sistema detectado: " . ($is_arch_based ? "Base Arch (BlackArch)" : "Base Debian (Kali/Parrot)") . "<br>";

    // --- 1. CORREÇÃO AUTOMÁTICA DO DRIVER MYSQLI ---
    if (!extension_loaded('mysqli')) {
        $log .= "Driver MySQLi não encontrado. Iniciando instalação automática...<br>";
        $v = substr(phpversion(), 0, 3);
        
        if ($is_debian_based) {
            $cmd_mysql_ext = "sudo apt-get update && sudo apt-get install -y php$v-mysql && sudo phpenmod mysqli";
            // Ativa no php.ini via sed para garantir
            shell_exec("sudo sed -i 's/;extension=mysqli/extension=mysqli/g' /etc/php/$v/apache2/php.ini");
            shell_exec("sudo sed -i 's/;extension=mysqli/extension=mysqli/g' /etc/php/$v/cli/php.ini");
        } else {
            $cmd_mysql_ext = "sudo pacman -S --noconfirm php-mysql && sudo sed -i 's/;extension=mysqli/extension=mysqli/g' /etc/php/php.ini";
        }
        shell_exec($cmd_mysql_ext . " 2>&1");
        $log .= "Driver MySQLi instalado e configurado.<br>";
    }

    // --- 2. MARIADB ---
    $has_mariadb = shell_exec("command -v mysql") || shell_exec("command -v mariadb");
    if (!$has_mariadb) {
        $log .= "Instalando MariaDB...<br>";
        if ($is_arch_based) {
            $cmd_db = "sudo pacman -S --noconfirm mariadb && sudo mariadb-install-db --user=mysql --basedir=/usr --datadir=/var/lib/mysql && sudo systemctl start mariadb";
        } else {
            $cmd_db = "export DEBIAN_FRONTEND=noninteractive && sudo apt update && sudo apt install -y mariadb-server mariadb-client && sudo systemctl start mariadb";
        }
        $log .= "<pre>" . shell_exec($cmd_db . " 2>&1") . "</pre>";
    } else {
        $log .= "MariaDB já presente. Garantindo que o serviço esteja ativo...<br>";
        shell_exec("sudo systemctl start mariadb 2>&1");
    }

    // --- CORREÇÃO DE PRIVILÉGIOS (ESSENCIAL PARA KALI) ---
    $log .= "Ajustando permissões de acesso do banco...<br>";
    $fix_auth = "sudo mysql -e \"ALTER USER 'root'@'localhost' IDENTIFIED VIA mysql_native_password; SET PASSWORD FOR 'root'@'localhost' = PASSWORD(''); FLUSH PRIVILEGES;\"";
    shell_exec($fix_auth . " 2>&1");

    // --- 3. PHP-XML ---
    if (!extension_loaded('dom') || !extension_loaded('simplexml')) {
        $log .= "Instalando extensões XML...<br>";
        if ($is_arch_based) {
            $cmd_xml = "sudo pacman -S --noconfirm php-xml libxml2 && " .
                       "sudo sed -i 's/;extension=dom/extension=dom/g' /etc/php/php.ini && " .
                       "sudo sed -i 's/;extension=xml/extension=xml/g' /etc/php/php.ini && " .
                       "sudo sed -i 's/;extension=simplexml/extension=simplexml/g' /etc/php/php.ini";
        } else {
            $cmd_xml = "export DEBIAN_FRONTEND=noninteractive && sudo apt-get update && sudo apt-get install -y php-xml";
        }
        $log .= "<pre>" . shell_exec($cmd_xml . " 2>&1") . "</pre>";
    } else {
        $log .= "Extensões XML ativas.<br>";
    }

    // Reiniciar servidor web para aplicar TUDO
    $log .= "Reiniciando servidor web para aplicar drivers...<br>";
    $restart_cmd = ($is_arch_based) ? "sudo systemctl restart httpd php-fpm" : "sudo systemctl restart apache2";
    shell_exec($restart_cmd . " 2>&1");

    return $log;
}

function conectar($senha) {
    if (!extension_loaded('mysqli')) {
        return false;
    }
    try {
        // No Kali, o uso do IP 127.0.0.1 força a conexão via TCP, evitando bugs de socket
        $conn = @new mysqli("127.0.0.1", "root", $senha);
        if ($conn->connect_errno) {
            $conn = @new mysqli("localhost", "root", $senha);
        }
        return ($conn->connect_errno) ? false : $conn;
    } catch (Throwable $t) { return false; }
}

function salvar_config($senha) {
    $senha_escapada = addslashes($senha);
    $conteudo = "<?php\n\$DB_HOST = '127.0.0.1';\n\$DB_USER = 'root';\n\$DB_PASS = '$senha_escapada';\n\$DB_NAME = 'meowna';\n\nfunction db_connect() {\n    \$conn = new mysqli(\$GLOBALS['DB_HOST'], \$GLOBALS['DB_USER'], \$GLOBALS['DB_PASS'], \$GLOBALS['DB_NAME']);\n    if (\$conn->connect_errno) die('Erro: ' . \$conn->connect_error);\n    if (!\$conn->select_db(\$GLOBALS['DB_NAME'])) die('Erro DB');\n    return \$conn;\n}\n?>";
    return file_put_contents("configuracao_db.php", $conteudo);
}

function instalar_db($conn) {
    $conn->query("CREATE DATABASE IF NOT EXISTS meowna");
    $conn->select_db("meowna");
    
    $conn->query("CREATE TABLE IF NOT EXISTS usuarios (id INT AUTO_INCREMENT PRIMARY KEY, usuario VARCHAR(50), senha VARCHAR(255), email VARCHAR(100), nome_completo VARCHAR(150), token VARCHAR(64), telefone VARCHAR(20), cpf VARCHAR(20), last_action INT DEFAULT 0, biografia TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("CREATE TABLE IF NOT EXISTS password_recovery (id INT PRIMARY KEY, email VARCHAR(255), otp INT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("CREATE TABLE IF NOT EXISTS posts (id INT PRIMARY KEY, likes INT NOT NULL DEFAULT 0, last_like_ts DECIMAL(20,6) DEFAULT 0) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("ALTER TABLE posts MODIFY last_like_ts DECIMAL(20,6) DEFAULT 0");
    $conn->query("INSERT IGNORE INTO posts (id, likes) VALUES (1, 0)");

    $suntzu = "“Se você conhece o inimigo e conhece a si mesmo, não precisa temer o resultado de cem batalhas. Se você se conhece mas não conhece o inimigo, para cada vitória ganha sofrerá também uma derrota. Se você não conhece nem o inimigo nem a si mesmo, perderá todas as batalhas.” - Sun Tzu";

    $usuarios = [
        ["maria", "senha123", "maria@example.com", "Maria Oliveira", "tok123maria", "31999990000", "123.456.789-00", $suntzu],
        ["joao", "pass01", "joao@example.com", "João Silva", "tok01", "31999990001", "111.222.333-44", ""],
        ["ana", "pass02", "ana@example.com", "Ana Santos", "tok02", "31999990002", "222.333.444-55", ""],
        ["carlos", "pass03", "carlos@example.com", "Carlos Pereira", "tok03", "31999990003", "333.444.555-66", ""],
        ["julia", "pass04", "julia@example.com", "Júlia Andrade", "tok04", "31999990004", "444.555.666-77", ""],
        ["david", "pass05", "david@example.com", "David Teixeira", "tok05", "31999990005", "555.666.777-88", ""]
    ];

    $stmt = $conn->prepare("INSERT IGNORE INTO usuarios (usuario, senha, email, nome_completo, token, telefone, cpf, biografia) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($usuarios as $u) {
        $stmt->bind_param("ssssssss", $u[0], $u[1], $u[2], $u[3], $u[4], $u[5], $u[6], $u[7]);
        $stmt->execute();
    }
}

// ---------------------------------------------------------
// LÓGICA DE EXECUÇÃO
// ---------------------------------------------------------
$mensagem = ""; $log_sistema = ""; $status = ""; $exigir_senha = false;

// Verificação inicial rápida
if (extension_loaded('mysqli')) {
    try {
        $teste = @new mysqli("localhost", "root", "");
        if ($teste->connect_errno == 1045) $exigir_senha = true;
        @$teste->close();
    } catch (Throwable $t) {}
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $senha = $_POST["senha_root"] ?? "";
    
    // Executa instalações de sistema (incluindo o driver se faltar)
    $log_sistema = instalar_dependencias_sistema();
    
    // Tenta conectar (se instalou agora, pode precisar de um refresh, mas o script tenta seguir)
    $conn = conectar($senha);

    if ($conn) {
        instalar_db($conn);
        salvar_config($senha);
        $conn->close();
        $status = "success";
        $mensagem = "Ambiente configurado com sucesso!";
    } else {
        $status = "danger";
        $mensagem = "O driver MySQLi foi instalado agora, mas o PHP ainda precisa ser recarregado para ativar a conexão.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Instalador meOwna</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <style>
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background-color: #f4f4f4; padding-top: 50px; }
        .install-box { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .btn-custom { background-color: #4883ff; color: white; border: none; }
        .btn-custom:hover { background-color: #3572ef; color: white; }
        pre { background: #222; color: #0f0; padding: 10px; font-size: 11px; max-height: 250px; overflow-y: auto; }
    </style>
</head>
<body>
    <div class="container">
        <div class="col-md-6 col-md-offset-3 install-box">
            <h2 class="text-center">Instalador de Ambiente</h2>
            <p class="text-center text-muted">Compatível com Kali, Parrot e BlackArch</p>
            <hr>
            
            <?php if ($mensagem): ?>
                <div class="alert alert-<?php echo $status; ?>"><?php echo $mensagem; ?></div>
                <?php if ($log_sistema): ?>
                    <div class="well well-sm"><strong>Log do Processo:</strong><br><?php echo $log_sistema; ?></div>
                <?php endif; ?>
                <?php if ($status === "success"): ?>
                    <a href="index.php" class="btn btn-primary btn-block">Abrir Laboratório</a>
                <?php else: ?>
                    <button onclick="window.location.reload();" class="btn btn-warning btn-block">Recarregar Página para Ativar Driver</button>
                <?php endif; ?>
            <?php endif; ?>

            <?php if ($status !== "success"): ?>
                <form method="POST">
                    <div class="form-group">
                        <label>Senha ROOT do MariaDB:</label>
                        <input type="password" name="senha_root" class="form-control" placeholder="<?php echo $exigir_senha ? 'Senha necessária' : 'Deixe vazio se não houver'; ?>" autofocus>
                    </div>
                    <button type="submit" class="btn btn-custom btn-block">Configurar e Instalar</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
