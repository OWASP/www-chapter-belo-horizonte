<?php
// export.php — handler para o laboratório XXE (intencionalmente inseguro)
// Aviso: NÃO usar isso em produção. Só para laboratório didático.

libxml_disable_entity_loader(false);
libxml_use_internal_errors(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Método inválido.";
    exit;
}

// pega XML de $_POST['xml_data'] (FormData) ou do corpo bruto (php://input)
$xml_bruto = null;
if (!empty($_POST['xml_data'])) {
    $xml_bruto = $_POST['xml_data'];
} else {
    $raw = file_get_contents('php://input');
    if (!empty($raw)) $xml_bruto = $raw;
}

if (empty($xml_bruto)) {
    header('Content-Type: text/plain; charset=utf-8');
    echo "Nenhum XML recebido.";
    exit;
}

// tenta processar (LIBXML_NOENT habilita entidades externas -> XXE)
$xml = simplexml_load_string($xml_bruto, "SimpleXMLElement", LIBXML_NOENT);

if ($xml === false) {
    header('Content-Type: text/plain; charset=utf-8');
    echo "Erro ao processar XML:\n";
    foreach (libxml_get_errors() as $err) {
        echo trim($err->message) . "\n";
    }
    libxml_clear_errors();
    exit;
}

// extrai campos para refletir
$nome_val = isset($xml->nome) ? (string)$xml->nome : '';
$email_val = isset($xml->email) ? (string)$xml->email : '';

// cria resposta XML refletindo o campo <nome> (usamos CDATA para preservar qualquer conteúdo)
header('Content-Type: application/xml; charset=utf-8');

$xml_response  = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
$xml_response .= "<userData>\n";
$xml_response .= "    <nome>" . $nome_val . "</nome>\n";
$xml_response .= "    <email>" . htmlspecialchars($email_val, ENT_XML1|ENT_SUBSTITUTE, 'UTF-8') . "</email>\n";
$xml_response .= "    <nome_completo>Maria Ferreira dos Santos</nome_completo>\n";
$xml_response .= "    <cpf>123.123.123-133</cpf>\n";
$xml_response .= "    <data_nascimento>12-07-1998</data_nascimento>\n";
$xml_response .= "    <numero_livros_lidos>42</numero_livros_lidos>\n";
$xml_response .= "    <senha>maria123456</senha>\n";
$xml_response .= "    <status_conta>ativa</status_conta>\n";
$xml_response .= "    <assinatura_premium>true</assinatura_premium>\n";
$xml_response .= "    <ultimo_login>12-03-2025 15:22:10</ultimo_login>\n";
$xml_response .= "</userData>";

echo $xml_response;
exit;

