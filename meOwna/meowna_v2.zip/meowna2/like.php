<?php
include 'configuracao_db.php';
header("Content-Type: application/json; charset=UTF-8");

$conn = db_connect();
$postId = 1;

// 1. Pegamos o tempo ATUAL direto do Banco de Dados com precisão de 6 casas
// Isso elimina qualquer diferença entre o relógio do PHP e do Sistema Operacional.
$resTime = $conn->query("SELECT UNIX_TIMESTAMP(NOW(6)) as db_now");
$rowTime = $resTime->fetch_assoc();
$now = (float)$rowTime['db_now'];

// 2. Busca o estado atual do post
$res = $conn->query("SELECT likes, last_like_ts FROM posts WHERE id = $postId");
$post = $res->fetch_assoc();

if (!$post) {
    $conn->query("INSERT INTO posts (id, likes, last_like_ts) VALUES ($postId, 0, 0)");
    $currentLikes = 0;
    $lastTs = 0;
} else {
    $currentLikes = (int)$post['likes'];
    $lastTs = (float)$post['last_like_ts'];
}

// 3. Cálculo da diferença (Agora usando apenas o tempo interno do banco)
$diff = $now - $lastTs;
$raceWindow = 0.8; 

// Debug para você acompanhar no terminal
$debug = [
    "db_clock_now" => $now,
    "db_stored_last" => $lastTs,
    "diff" => $diff,
    "is_race" => ($diff < $raceWindow && $lastTs > 0)
];

// 4. Lógica da Vulnerabilidade
if ($lastTs > 0 && $diff < $raceWindow) {
    
    // --- MODO RACE ---
    $newLikes = $currentLikes + 1;
    // NÃO atualizamos o timestamp para manter a janela aberta
    $conn->query("UPDATE posts SET likes = $newLikes WHERE id = $postId");
    $message = "Race Condition Exploited!";
    $raceDetected = true;

} else {
    
    // --- MODO NORMAL ---
    $newLikes = ($currentLikes > 0) ? 0 : 1;
    // Atualizamos o timestamp com a precisão máxima do banco
    $conn->query("UPDATE posts SET likes = $newLikes, last_like_ts = $now WHERE id = $postId");
    $message = "Normal Toggle (Success)";
    $raceDetected = false;
}

echo json_encode([
    "message" => $message,
    "likes" => $newLikes,
    "race_detected" => $raceDetected,
    "debug" => $debug
], JSON_PRETTY_PRINT);
